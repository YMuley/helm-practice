{{/*
Common labels
*/}}
{{- define "nginx.labels" -}}
app: {{ .Values.name | lower }}
{{- if eq .Values.environment "production" }}
environment: {{ .Values.labels.production.environment | lower }}
build: {{ .Values.labels.production.build | lower }}
public_facing: {{ .Values.labels.production.public_facing | lower }}
{{- else }}
environment: {{ .Values.labels.dev.environment | lower }}
build: {{ .Values.labels.dev.build | lower }}
public_facing: {{ .Values.labels.dev.public_facing | lower }}
{{- end }}
{{- end }}